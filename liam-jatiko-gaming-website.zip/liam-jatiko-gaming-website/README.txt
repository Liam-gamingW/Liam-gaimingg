LIAM JATIKO GAMING WEBSITE

Files:
- index.html: website structure
- style.css: visual design and mobile layout
- script.js: search and mobile menu
- assets/: banner and game thumbnail images cropped from your reference screenshot

GITHUB PAGES ON ANDROID:
1. Download and extract liam-jatiko-gaming-website.zip.
2. Open your GitHub repository in Chrome.
3. Upload index.html, style.css, script.js, and the entire assets folder (including its images).
4. Commit the files to your main branch.
5. Open Settings > Pages. Set deployment source to Deploy from a branch, select main and / (root), then Save.
6. Wait for the Pages deployment to finish and open the site URL.

IMPORTANT:
- This is a static front-end demo. Replace social links and video destinations with your real channel links.
- The banner and game thumbnail crops come from the screenshot you provided so the layout resembles it closely.
