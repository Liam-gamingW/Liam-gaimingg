const searchInput = document.getElementById('searchInput');
const cards = [...document.querySelectorAll('.game-card')];
const noResults = document.getElementById('noResults');
searchInput?.addEventListener('input', () => {
  const term = searchInput.value.trim().toLowerCase();
  let shown = 0;
  cards.forEach(card => {
    const match = card.dataset.search.toLowerCase().includes(term);
    card.hidden = !match;
    if (match) shown++;
  });
  noResults.hidden = shown !== 0;
});
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');
menuToggle?.addEventListener('click', () => navLinks.classList.toggle('open'));
navLinks?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => navLinks.classList.remove('open')));
document.getElementById('year').textContent = new Date().getFullYear();
